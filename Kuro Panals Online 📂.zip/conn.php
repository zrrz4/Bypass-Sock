<?php

$servername = "localhost";
$username = "krishnap_krishnapratap";
$password = "krishnap_krishnapratap";
$dbname = "krishnap_krishnapratap";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>