<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<h1 class="text-center" style="color: black; font-size: 15px; letter-spacing: 2px; text-align: center;">
  <marquee direction="left" scrollamount="10">
<!--    <b style="color: #d3d3d3;">-->
<!--        𝙼𝚄𝚂𝚃 𝙹𝙾𝙸𝙽 𝙾𝚄𝚁 <span style="color: yellow;">𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼 𝙲𝙷𝙰𝙽𝙽𝙴𝙻</span> 𝙵𝙾𝚁 𝚄𝙿𝙳𝙰𝚃𝙴𝚂:--->
<!--</b>-->
<!--<a style="color: #39ff14;" href="https://t.me/venomvippanel" target="_blank">-->
<!--  <b><i class="fab fa-telegram-plane"></i> @ᴠᴇɴᴏᴍᴠɪᴘᴘᴀɴᴇʟ <i class="fab fa-telegram-plane"></i></b>-->
<!--</a>-->

    <span style="color: white;">
     ɪғ ʏᴏᴜ <span style="color: yellow;">ᴡᴀɴᴛ ʙᴜʏ ᴘᴀɪᴅ ᴘᴀɴᴇʟ</span>
      <!--ɪғ ʏᴏᴜ <span style="color: #08e8de;">ᴡᴀɴᴛ ʙᴜʏ ᴘᴀɪᴅ ᴘᴀɴᴇʟ</span>  -->
      <span style="color: red;"></span> ᴄᴏɴᴛᴀᴄᴛ ᴛᴏ ᴏᴡɴᴇʀ :-
    </span>
    <a style="color: #39ff14;" href="https://t.me/venom_pratap" target="_blank">
      <b>@𝐕𝐄𝐍𝐎𝐌 𝐏𝐑𝐀𝐓𝐀𝐏 ꨄ </b>
    </a>
  </marquee>
</h1>



<!--<h1 class="text-center" style="color: black; font-size: 15px; letter-spacing: 2px; text-align: center;">-->
<!--  <marquee direction="left" scrollamount="10">-->
<!--    <b style="color: red;">-->
<!--  THIS PANEL DOMAIN EXPIRES SOON. KINDLY JOIN OUR TELEGRAM CHANNEL FOR NEW PANEL AND UPDATES:--->
<!--</b>-->
<!--<a style="color: white;" href="https://t.me/venomvippanel" target="_blank">-->
<!--  <b><i class="fab fa-telegram-plane"></i> VENOMVIPPANEL <i class="fab fa-telegram-plane"></i></b>-->
<!--</a>-->

<!--    <span style="color: white;">-->
<!--      | Any issues <span style="color: red;">related</span> to the panel or if you want to create your own-->
<!--      <span style="color: red;">private</span> panel, contact the owner:-->
<!--    </span>-->
<!--    <a style="color: yellow;" href="https://t.me/venom_pratap" target="_blank">-->
<!--      <b>Venom Pratap</b>-->
<!--    </a>-->
<!--  </marquee>-->
<!--</h1>-->


<div class="row justify-content-center pt-2">
    <div class="col-lg-4">
                   <div class="alert alert-primary text-center alert-dismissible fade show  "role="alert" style="animation: blink 1s linear infinite; -webkit-animation: blink 1.2s linear infinite;"> <style>@keyframes blink { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }</style>
            Create Your Free Account <br>
 <a href="register" class="text-danger">Register here</a>
        </div>
        <div class="card shadow-sm mb-5">
            <div class="card-header h5 p-3 text-center">
<html>
<head>
    <title>Flashing Fonts</title>
    <style>
        .flashing {
            font-size: 30px;
            animation: flashing 1s infinite;
        }

        @keyframes flashing {
            0% { color: red; }
            50% { color: blue; }
            100% { color: black; }
        }
    </style>
</head>
<body>
    <span class='flashing'>𝙒𝞮𝙡𝙘𝞸𝙢𝞮 𝘽𝞪𝙗𝞬</span></body>
</html>
<!--CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT -->
   
<!--  CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..-->

   
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="username" class="text-white">Username</label>
                    <input type="text" class="form-control mt-2" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4">
                                    </div>
                <div class="form-group mb-3">
                    <label for="password">Password</label>
                    <div class="position-relative">
                    <input type="password" class="form-control mt-2" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <span class="position-absolute top-50 end-0 translate-middle-y me-3" id="togglePassword" style="cursor: pointer;">
                   <i class="fa fa-eye-slash"></i>
                   
                   <!--CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT -->
   
<!--  CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..-->
                   </span>
                </div>
                                    </div>
                
                <!-- FontAwesome for the eye icon -->
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

              <script>
                 document.getElementById('togglePassword').addEventListener('click', function () {
                 var passwordInput = document.getElementById('password');
                 var icon = this.querySelector('i');

                     if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                 } else {
                    passwordInput.type = 'password';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                       }
                      });
              </script>
                
                
<!--       CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT -->
   
  <!--CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..         -->
                
                
                <!---->
                
                 <div class="form-group mb-3">
                    <input type="hidden" class="form-control mt-2" name="ip" value="Mozilla/5.0 (Linux; Android 14; 22041216I Build/UP1A.231005.007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.60 Mobile Safari/537.36" id="ip" aria-describedby="help-ip" required>
                    
                                    </div>
                
                <!--CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT -->
   
<!--  CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..-->
                <!---->
                
                <div class="form-check mb-3">
          <label class="form-check-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes"> <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes"> Stay login </label>
          </div>
          <div class="form-group mb-2 d-flex justify-content-between align-items-center">
          <button type="submit" class="btn btn-outline-dark"><i class="bi bi-box-arrow-in-right"></i> 𝐋𝐨𝐠𝐢𝐧</button>
          
         <a href="Venom_Panel.apk" class="download-btn" download>
           <span class="icon">📥</span> Download APK
              </a>

            <style>
               .download-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 15px;
            font-size: 12px;
            color: #fff;
            background: linear-gradient(45deg, #64ff33, #28a745);
            border: none;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
            transition: 0.4s ease-in-out;
            box-shadow: 0px 4px 10px rgba(255, 65, 108, 0.5);
            position: relative;
            overflow: hidden;
             }

           /* Continuous up & down animation */
           .icon {
            display: inline-block;
            font-size: 20px;
            margin-right: 10px;
            animation: bounce 1s infinite alternate ease-in-out;
             }

           @keyframes bounce {
           0% { transform: translateY(-5px); }
           100% { transform: translateY(5px); }
            }

          /* Hover effect for button */
          .download-btn:hover {
           background: linear-gradient(45deg, #ff416c, #ff4b2b);
           transform: scale(1.05);
           box-shadow: 0px 6px 12px rgba(100, 255, 51, 0.6);
            }

         .download-btn:active {
         transform: scale(0.95);
          }
         </style>

                         </div>
                </form>            </div>
        </div>
<!--        CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT --> 
   
<!--  CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..-->

        <p class="text-center text-white after-card">
  <small class="px-auto p-2 rounded">
   𝐉𝐎𝐈𝐍 𝐔𝐏𝐃𝐀𝐓𝐄𝐒 :- 
    <!--<a href="https://whatsapp.com/channel/0029VbAOfCzDJ6GsnGy6ht3k" class="bi bi-whatsapp text-green" -->
    <!--   style="animation: blink 1s infinite; color: #39ff14; text-decoration: none;">-->
    <!--  𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 <i class=""></i>-->
    <!--</a> |-->
    <a href="https://t.me/+QW6Vx7_9WcgyMDg9" class=" bi bi-telegram text-blue" 
       style="animation: blink 1s infinite; color: #08e8de; text-decoration: none;">
      𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 <i class=" bi bi-telegram text-blue"></i>
    </a>
  </small>
</p>

<!--CODE DIKA KAR KIYA KAR LOGE MADHAR CHOD -->
<!--RANDI K BACCHA TERI MAA KI CHUT-->
<!--PAHLE PANEL DESEN KARNA KHUD SE SIKHA RANDI K BACCCHA-->
<!--CHAAL AB VENOM PAPA BOL N MADHER CHOD-->
<!--JO YE MESSSSASE PADH RAHA HAI OO RANDI K BACCCCHA HAI-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->


<!--TERI MAA KI CHUT-->
<!--TERI DIDI KI CHUT PE VENOM K LUND MADHERCHOD-->
<!--TERI NANI K CHUT BSDK-->
   
<!--   AB BOL N KIDS DEVOPERS K CHODA BANEGA...-->
<!--   PANEL CRAKER K JHAT K BAAL BANEGA.-->
   
<!--   TERI MAA KI CHUT -->
   
<!--  CODE DIKA KAR CLONE MAREGA RANDI K BACCHA..-->     

       <style>
       @keyframes blink {
       0% { opacity: 1; }
       50% { opacity: 0; }
       100% { opacity: 1; }
         }
    </style>

<script>
document.querySelector('.toggle-password').addEventListener('click', function() {
    const password = document.querySelector('#password');
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    this.classList.toggle('fa-eye');
    this.classList.toggle('fa-eye-slash');
});
</script>

<?= $this->endSection() ?>